package UninaFoodLab.DTO;

public enum UnitaDiMisura
{
    Unita,
    Grammi,
    Kilogrammi,
    Litri,
    Millilitri,
    Bicchiere,
    Tazza,
    Tazzina,
    Cucchiaio,
    Cucchiaino
}