package UninaFoodLab.DTO;

public enum NaturaIngrediente
{
    Vegetale,
    Animale,
    Minerale,
    Fungino,
    Sintetico,
    Microbico,
    Altro
}