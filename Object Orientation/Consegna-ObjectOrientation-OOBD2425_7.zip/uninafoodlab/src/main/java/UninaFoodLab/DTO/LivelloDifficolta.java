package UninaFoodLab.DTO;

public enum LivelloDifficolta
{
    Principiante,
    Facile,
    Medio,
    Difficile,
    Esperto
}