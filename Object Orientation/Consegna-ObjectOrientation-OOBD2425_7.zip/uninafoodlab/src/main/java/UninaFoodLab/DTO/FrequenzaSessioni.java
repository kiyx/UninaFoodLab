package UninaFoodLab.DTO;

public enum FrequenzaSessioni
{
	Giornaliera,
	Settimanale,
	Bisettimanale,
	Mensile,
	Libera	
}